// test_reproducibility.cpp — proves CORE-MATH (detmath) produces bit-identical
// results on this platform/compiler.
//
// Build & run this SAME test on every platform in your matrix:
//   Windows/MSVC-hosted (detmath.lib built with clang-cl), Windows/clang-cl,
//   Linux/gcc, Linux/clang. All must print the same thing: every check PASS.
//
// The golden values in coremath_golden.h are the unique correctly rounded
// results — not "reference machine outputs". A failure here is never a
// legitimate platform difference; it is a build defect. The environment
// checks at the top exist to tell you WHICH defect:
//
//   FAIL fp_eval_method   -> x87/extended intermediates (32-bit build?)
//   FAIL no_contraction   -> compiler fusing a*b+c into FMA in THIS test TU;
//                            if your flags allow it here, they likely allow
//                            it in your pricing code too (gcc default!)
//   FAIL no_ftz_daz       -> something linked fast-math (crtfastmath.o) or
//                            set MXCSR flush-to-zero; denormals break
//   FAIL round_to_nearest -> rounding mode altered
//   KAT/sweep failures with env checks passing -> wrong/stale detmath.lib,
//                            LLP64 regression, or contraction inside the lib
//
// Exit code 0 = fully reproducible.

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cfloat>
#include <cfenv>

#include "coremath_golden.h"

extern "C" {
double cr_exp(double); double cr_log(double); double cr_pow(double, double);
double cr_expm1(double); double cr_log1p(double);
double cr_erf(double); double cr_erfc(double);
}

static uint64_t bitsOf(double d){ uint64_t u; std::memcpy(&u,&d,8); return u; }
static double fromBits(uint64_t u){ double d; std::memcpy(&d,&u,8); return d; }

struct SplitMix64 {
    uint64_t s;
    explicit SplitMix64(uint64_t seed): s(seed) {}
    uint64_t next(){ uint64_t z=(s+=0x9E3779B97F4A7C15ull);
        z=(z^(z>>30))*0xBF58476D1CE4E5B9ull; z=(z^(z>>27))*0x94D049BB133111EBull;
        return z^(z>>31); }
    double u01(){ return (double)(next()>>11)*0x1.0p-53; }
    double uniform(double lo,double hi){ return lo+u01()*(hi-lo); }
    double logUniformPos(int eLo,int eHi){
        uint64_t m=next()&0x000FFFFFFFFFFFFFull;
        uint64_t e=(uint64_t)(eLo+(int)(next()%(uint64_t)(eHi-eLo+1)));
        return fromBits((e<<52)|m); }
};

struct Fnv {
    uint64_t h=0xCBF29CE484222325ull;
    void addD(double d){ uint64_t u=bitsOf(d);
        for(int k=0;k<8;k++){ h^=(u>>(8*k))&0xff; h*=0x100000001B3ull; } }
};

static int g_fail = 0;
static void check(bool ok, const char* what) {
    std::printf("%-24s %s\n", what, ok ? "PASS" : "FAIL");
    if (!ok) ++g_fail;
}

// ---------------------------------------------------------------------------
// 1) Floating-point environment sanity — diagnoses WHY goldens would fail
// ---------------------------------------------------------------------------
static void envChecks() {
    // doubles evaluated as doubles, no extended intermediates
    check(FLT_EVAL_METHOD == 0, "fp_eval_method==0");

    // contraction detector: choose a,b,c where fma(a,b,c) != round(a*b)+c.
    // a=b=1+2^-27: exact a*b = 1+2^-26+2^-54; rounds to 1+2^-26.
    // c=-(1+2^-26): unfused result 0; fused result 2^-54.
    {
        volatile double av = 1.0 + 0x1.0p-27, cv = -(1.0 + 0x1.0p-26);
        volatile double p = av * av;        // forced separate rounding
        double unfused = p + cv;
        double maybe   = av * av + cv;      // fresh volatile reads: CSE cannot
                                            // reuse p, so this MAY be fused
        check(bitsOf(maybe) == bitsOf(unfused), "no_contraction");
    }

    // denormals must survive (FTZ/DAZ off)
    {
        volatile double tiny = DBL_MIN;
        volatile double half = tiny * 0.5;   // denormal if !FTZ
        volatile double back = half * 2.0;   // DBL_MIN again if !DAZ
        check(half != 0.0 && back == DBL_MIN, "no_ftz_daz");
    }

    check(std::fegetround() == FE_TONEAREST, "round_to_nearest");

    // basic-op determinism canary (IEEE-exact; must hold anywhere)
    check(bitsOf(0.1 + 0.2) == 0x3FD3333333333334ull, "ieee_basic_ops");
}

// ---------------------------------------------------------------------------
// 2) Known-answer tests: every embedded vector must match bit-for-bit
// ---------------------------------------------------------------------------
template <size_t N>
static void kat1(const char* name, double (*fn)(double), const KAT1 (&v)[N]) {
    size_t bad = 0; uint64_t exIn = 0, exGot = 0, exWant = 0;
    for (size_t i = 0; i < N; ++i) {
        uint64_t got = bitsOf(fn(fromBits(v[i].in)));
        if (got != v[i].out && !bad) { exIn = v[i].in; exGot = got; exWant = v[i].out; }
        bad += (got != v[i].out);
    }
    char label[64]; std::snprintf(label, sizeof(label), "kat_%s (%zu vec)", name, N);
    check(bad == 0, label);
    if (bad) std::printf("    first miss: in=%016llx got=%016llx want=%016llx (%zu wrong)\n",
        (unsigned long long)exIn, (unsigned long long)exGot,
        (unsigned long long)exWant, bad);
}

// ---------------------------------------------------------------------------
// 3) Sweep hashes: 1M deterministic inputs per function, FNV over in+out bits
// ---------------------------------------------------------------------------
static const int N_SWEEP = 1000000;

static void sweep1(const char* name, double (*fn)(double), uint64_t seed,
                   double (*gen)(SplitMix64&), const KAT1* edge, int /*nKat*/,
                   uint64_t expected) {
    SplitMix64 rng(seed); Fnv h;
    for (int i = 0; i < N_SWEEP; ++i) {
        // regenerate exactly as gen_golden did: first 8 edge inputs
        // (recorded in the KAT table), then the PRNG stream
        double x = (i < 8) ? fromBits(edge[i].in) : gen(rng);
        double y = fn(x);
        h.addD(x); h.addD(y);
    }
    char label[64]; std::snprintf(label, sizeof(label), "sweep_%s (1M)", name);
    check(h.h == expected, label);
    if (h.h != expected)
        std::printf("    hash got=%016llx want=%016llx\n",
            (unsigned long long)h.h, (unsigned long long)expected);
}

int main() {
    std::printf("=== detmath / CORE-MATH cross-platform reproducibility test ===\n");
#if defined(_MSC_VER) && !defined(__clang__)
    std::printf("host compiler: MSVC %d\n", _MSC_FULL_VER);
#elif defined(__clang__)
    std::printf("host compiler: clang %d.%d\n", __clang_major__, __clang_minor__);
#elif defined(__GNUC__)
    std::printf("host compiler: gcc %d.%d\n", __GNUC__, __GNUC_MINOR__);
#endif
    std::printf("sizeof(long)=%zu (LLP64=%s)\n\n", sizeof(long),
                sizeof(long) == 4 ? "yes" : "no");

    std::printf("-- environment --\n");
    envChecks();

    std::printf("\n-- known-answer vectors (correctly rounded => unique) --\n");
    kat1("exp",   cr_exp,   kat_exp);
    kat1("log",   cr_log,   kat_log);
    kat1("expm1", cr_expm1, kat_expm1);
    kat1("log1p", cr_log1p, kat_log1p);
    kat1("erf",   cr_erf,   kat_erf);
    kat1("erfc",  cr_erfc,  kat_erfc);
    {   // pow
        size_t bad = 0;
        for (auto& v : kat_pow)
            bad += (bitsOf(cr_pow(fromBits(v.in1), fromBits(v.in2))) != v.out);
        check(bad == 0, "kat_pow (64 vec)");
    }

    std::printf("\n-- 1M-sample sweep hashes --\n");
    sweep1("exp",   cr_exp,   0xB0001,
        [](SplitMix64& r){ return r.uniform(-745.0, 710.0); }, kat_exp,   64, sweep_exp);
    sweep1("log",   cr_log,   0xB0002,
        [](SplitMix64& r){ return r.logUniformPos(1, 2045); }, kat_log,   64, sweep_log);
    sweep1("expm1", cr_expm1, 0xB0003,
        [](SplitMix64& r){ return r.uniform(-40.0, 40.0); },   kat_expm1, 64, sweep_expm1);
    sweep1("log1p", cr_log1p, 0xB0004,
        [](SplitMix64& r){ return r.uniform(-0.9999999, 1e6); }, kat_log1p, 64, sweep_log1p);
    sweep1("erf",   cr_erf,   0xB0005,
        [](SplitMix64& r){ return r.uniform(-6.5, 6.5); },     kat_erf,   64, sweep_erf);
    sweep1("erfc",  cr_erfc,  0xB0006,
        [](SplitMix64& r){ return r.uniform(-6.0, 28.0); },    kat_erfc,  64, sweep_erfc);
    {   // pow sweep
        SplitMix64 rng(0xB0007); Fnv h;
        for (int i = 0; i < N_SWEEP; ++i) {
            double x, y;
            if (i < 8) { x = fromBits(kat_pow[i].in1); y = fromBits(kat_pow[i].in2); }
            else { x = rng.logUniformPos(1023-30, 1023+30); y = rng.uniform(-30.0, 30.0); }
            double z = cr_pow(x, y);
            h.addD(x); h.addD(y); h.addD(z);
        }
        check(h.h == sweep_pow, "sweep_pow (1M)");
    }

    std::printf("\n%s (%d failure%s)\n",
        g_fail ? "REPRODUCIBILITY: FAIL" : "REPRODUCIBILITY: PASS — bit-identical",
        g_fail, g_fail == 1 ? "" : "s");
    return g_fail ? 1 : 0;
}
