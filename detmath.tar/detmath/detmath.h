// detmath.h — deterministic elementary functions for cross-OS / cross-compiler
// bit reproducibility, backed by CORE-MATH correctly rounded implementations.
//
// Correct rounding means exactly ONE valid double result per input, so outputs
// are bit-identical across Windows/Linux, MSVC/clang-cl/gcc, and CPU models —
// by specification, independent of ucrtbase.dll version or CPU dispatch.
//
// IMPORTANT: the coremath/*.c translation units MUST be compiled with
// clang-cl (Windows) or clang/gcc (Linux) — never MSVC cl (they use __int128,
// GCC builtins, and vector extensions). Build them ONCE into detmath.lib with
// clang-cl and link that same .lib into both your MSVC and clang-cl builds:
// identical machine code for the math in both build flavors.
//
// A/B switch: define DETMATH_USE_CRT to route back to the CRT for validating
// pricing impact before committing.
//
// Upstream: https://gitlab.inria.fr/core-math/core-math   (MIT license)
// MSVC-friendly mirror maintained by the Principia project (which uses
// CORE-MATH for exactly this purpose — cross-platform bit reproducibility):
// https://github.com/mockingbirdnest/core-math

#pragma once
#include <cmath>

#if !defined(DETMATH_USE_CRT)
extern "C" {
double cr_exp(double);
double cr_log(double);
double cr_pow(double, double);
double cr_expm1(double);
double cr_log1p(double);
double cr_erf(double);
double cr_erfc(double);
}
#endif

namespace detmath {

#if defined(DETMATH_USE_CRT)
inline double exp(double x)             { return std::exp(x); }
inline double log(double x)             { return std::log(x); }
inline double pow(double x, double y)   { return std::pow(x, y); }
inline double expm1(double x)           { return std::expm1(x); }
inline double log1p(double x)           { return std::log1p(x); }
inline double erf(double x)             { return std::erf(x); }
inline double erfc(double x)            { return std::erfc(x); }
#else
inline double exp(double x)             { return cr_exp(x); }
inline double log(double x)             { return cr_log(x); }
inline double pow(double x, double y)   { return cr_pow(x, y); }
inline double expm1(double x)           { return cr_expm1(x); }
inline double log1p(double x)           { return cr_log1p(x); }
inline double erf(double x)             { return cr_erf(x); }
inline double erfc(double x)            { return cr_erfc(x); }
#endif

// sqrt is an IEEE-exact operation: the CRT/hardware result is already
// bit-deterministic everywhere. Provided for uniform call-site style.
inline double sqrt(double x)            { return std::sqrt(x); }

// Normal CDF/quantile built ONLY from deterministic pieces above.
inline double norm_cdf(double x) {
    // Phi(x) = erfc(-x / sqrt(2)) / 2 ; fixed constant, fixed op order.
    return 0.5 * detmath::erfc(x * -0.70710678118654752440);
}

} // namespace detmath
